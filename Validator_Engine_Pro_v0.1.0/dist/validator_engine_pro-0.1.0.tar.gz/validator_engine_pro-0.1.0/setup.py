from setuptools import setup, find_packages

setup(
    name="validator_engine_pro",
    version="0.1.0",
    author="Kylik Daniels Labs",
    description="Enterprise-grade real-time stream optimization and JSON validation middleware for LLMs.",
    packages=find_packages(),
    install_requires=[
        "fastapi",
        "uvicorn",
        "requests"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
